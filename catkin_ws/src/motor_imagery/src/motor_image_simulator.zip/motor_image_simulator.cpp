#include "ros/ros.h"
#include "std_msgs/String.h"
#include "geometry_msgs/Twist.h"

ros::Publisher pub;
ros::Subscriber sub;
std_msgs::String direction_msg;


void ProbCB(std_msgs::String msg)
{

  string line = msg.data;
  line = line.substr(1, line.size() - 2);
  cout << fixed << setprecision(2);
  // Vector of string to save tokens
  vector<string> tokens;
  // stringstream class check1
  stringstream check1(line);
  string intermediate;
  std_msgs::String command;
  geometry_msgs::PoseStamped command_int;
  // Tokenizing w.r.t. space ' '
  while (getline(check1, intermediate, ','))
  {
    tokens.push_back(intermediate);
  }

  //prob.resize(tokens.size());
  //for (int i = 0; i < tokens.size(); i++)
  //{
   // prob[i] = stod(tokens[i]);
  //}
  prob.resize(tokens.size());
  for (int i = 0; i < tokens.size(); i++)
  {
     prob[i] = stod(tokens[i]);
  }  

  double y;
    y = filter1->ComputeY(prob[0]);

    //cout << "Uscita: " << y << "\n\n";

    if (y > 0.5 + filter1->GetOmega())
    {
      command.data = "LEFT";
      string_pub.publish(command);

      command_int.header.stamp = ros::Time::now();
      command_int.pose.position.x = 0;
      command_pub.publish(command_int);
    }
    else if (y < 0.5 - filter1->GetOmega())
    {
      command.data = "RIGHT";
      string_pub.publish(command);

      command_int.header.stamp = ros::Time::now();
      command_int.pose.position.x = 1;
      command_pub.publish(command_int);
    }

}










// void chatterCallback(const geometry_msgs::Twist::ConstPtr& msg){

//     ROS_INFO("Lo spostamento richiesto è: [%f]",msg->linear.x);

//     if(msg->linear.x > 0){
        
//         direction_msg.data = "LEFT";
//     }
//     else if (msg->linear.x < 0)
//     {   
//         direction_msg.data = "RIGHT";

//     }

//     pub.publish(direction_msg);

// }


int main (int argc, char **argv){

    ros::init (argc,argv, "motor_image_simulator");

    ros::NodeHandle n;

    sub = n.subscribe("/cmd_vel",1,chatterCallback);

    pub = n.advertise <std_msgs::String>("/direction",1);



    ros::spin();
    return 0;

}
